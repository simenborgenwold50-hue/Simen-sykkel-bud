# Simen Sykkelbud 🚴‍♂️

Hei! Jeg heter **Simen Borgen Wold**, og dette er min nettside.  
Her finner du informasjon om meg, hva jeg driver med som sykkelbud, og litt om mine hobbyer.

## 🌍 Om nettsiden
- **Firma**: Simen Sykkelbud i Lillehammer  
- **Transport**: Elsykkel + sykkelhenger for små og store oppdrag  
- **Fokus**: Miljøvennlig, effektiv og personlig levering  
- **Hobby**: Fotografering, sykkelturer og små prosjekter  

## 📸 Innhold
- **Forside / Hero** med introduksjon  
- **Om meg** med min historie og hvorfor jeg startet  
- **Tjenester** med oversikt over hva jeg tilbyr  
- **Hobby** med mine interesser  
- **Galleri** med bilder fra sykkel- og hverdagslivet  
- **Kontakt** med telefon og e-post  

## 📬 Kontakt
- Telefon: +47 413 41 117  
- E-post: simenborgenwold50@gmail.com  

---

🚴‍♂️ Laget med kjærlighet til sykling og hverdagsglede.
